package com.ruben.wifianalyzer

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DD0E1),
    onPrimary = Color(0xFF00363D),
    secondary = Color(0xFF80CBC4),
    background = Color(0xFF0B1620),
    onBackground = Color(0xFFE3EEF3),
    surface = Color(0xFF0F1D29),
    onSurface = Color(0xFFE3EEF3),
    surfaceVariant = Color(0xFF1A2B3A),
    onSurfaceVariant = Color(0xFFA9BCC8),
    outline = Color(0xFF3B5163)
)

@Composable
fun WifiAnalyzerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
