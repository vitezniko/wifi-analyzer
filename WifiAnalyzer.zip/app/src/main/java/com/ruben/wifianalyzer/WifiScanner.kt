package com.ruben.wifianalyzer

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class WifiScanner(context: Context) {
    private val app = context.applicationContext
    private val wifiManager = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val locationManager = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun isLocationEnabled(): Boolean = locationManager.isLocationEnabled

    @SuppressLint("MissingPermission")
    fun readResults(): List<ScanResult> = try {
        wifiManager.scanResults ?: emptyList()
    } catch (e: SecurityException) {
        emptyList()
    }

    @Suppress("DEPRECATION")
    fun requestScan(): Boolean = try {
        wifiManager.startScan()
    } catch (e: SecurityException) {
        false
    }

    /** Emite la lista de redes cada vez que Android termina un escaneo. */
    fun resultsFlow(): Flow<List<ScanResult>> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                trySend(readResults())
            }
        }
        ContextCompat.registerReceiver(
            app,
            receiver,
            IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        trySend(readResults())
        awaitClose { runCatching { app.unregisterReceiver(receiver) } }
    }

    /** Ubicacion actual: primero GPS, si no hay fix usa la ubicacion de red. */
    suspend fun currentLocation(): Location? {
        if (!hasLocationPermission()) return null
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { locationManager.isProviderEnabled(it) }.getOrDefault(false) }
        for (provider in providers) {
            val loc = withTimeoutOrNull(7000L) { fetch(provider) }
            if (loc != null) return loc
        }
        return null
    }

    @SuppressLint("MissingPermission")
    private suspend fun fetch(provider: String): Location? =
        suspendCancellableCoroutine<Location?> { cont ->
            val signal = CancellationSignal()
            cont.invokeOnCancellation { signal.cancel() }
            try {
                locationManager.getCurrentLocation(
                    provider,
                    signal,
                    ContextCompat.getMainExecutor(app)
                ) { loc ->
                    if (cont.isActive) cont.resume(loc)
                }
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
}
