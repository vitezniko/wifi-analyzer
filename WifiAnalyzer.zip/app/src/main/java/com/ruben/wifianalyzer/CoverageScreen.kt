@file:OptIn(ExperimentalMaterial3Api::class)

package com.ruben.wifianalyzer

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

@Composable
fun CoverageScreen(
    state: WifiUiState,
    onMapping: (Boolean) -> Unit,
    onMark: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val best = state.bestPoint

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(colors = cardColors(), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Registrar puntos automaticamente", style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (state.trackedSsid != null) "Siguiendo la red: ${state.trackedSsid}"
                        else "Guarda la posicion junto a la red mas potente (o toca una red en la pestana Redes para seguir solo esa).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = state.mappingEnabled, onCheckedChange = onMapping)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onMark, enabled = !state.locating) { Text("Marcar punto ahora") }
            OutlinedButton(onClick = onClear, enabled = state.points.isNotEmpty()) { Text("Borrar") }
        }

        if (state.locating) {
            Text("Obteniendo ubicacion...", style = MaterialTheme.typography.bodySmall)
        }
        state.locationNotice?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }

        if (best != null) {
            Card(colors = cardColors(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("Mejor cobertura registrada", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${best.ssid} - ${best.rssi} dBm (${signalLabel(best.rssi)})",
                        color = signalColor(best.rssi),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        String.format(Locale.US, "%.6f, %.6f", best.latitude, best.longitude),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { openInMaps(context, best) }) { Text("Abrir en Google Maps") }
                }
            }

            MiniMap(
                points = state.points,
                best = best,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            )
            Text(
                "Verde: mejor que -50 dBm. Amarillo: media. Rojo: peor que -80 dBm. " +
                    "El circulo blanco marca el mejor punto. Los puntos se pierden al cerrar la app.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text("Ultimos puntos", style = MaterialTheme.typography.titleSmall)
            state.points.takeLast(15).reversed().forEach { p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(signalColor(p.rssi), CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${formatTime(p.timeMillis)} - ${p.ssid} - ${p.rssi} dBm" +
                            if (p.manual) " - manual" else "",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else {
            Text(
                "Todavia no hay puntos. Camina por la casa con la app abierta: cada vez que te muevas " +
                    "unos metros guardara tu posicion y la potencia de la red. Dentro de casa el GPS " +
                    "es poco preciso: si ves que falla, usa \"Marcar punto ahora\" en cada habitacion.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MiniMap(points: List<MeasurePoint>, best: MeasurePoint?, modifier: Modifier = Modifier) {
    val bg = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier.clip(RoundedCornerShape(12.dp)).background(bg)) {
        val minLat = points.minOf { it.latitude }
        val maxLat = points.maxOf { it.latitude }
        val minLon = points.minOf { it.longitude }
        val maxLon = points.maxOf { it.longitude }
        val lonScale = cos(Math.toRadians((minLat + maxLat) / 2.0))
        val spanX = max((maxLon - minLon) * lonScale, 1e-5)
        val spanY = max(maxLat - minLat, 1e-5)
        val w = size.width.toDouble()
        val h = size.height.toDouble()
        val pad = 24.dp.toPx().toDouble()
        val scale = min((w - 2 * pad) / spanX, (h - 2 * pad) / spanY)
        val ox = (w - spanX * scale) / 2.0
        val oy = (h - spanY * scale) / 2.0

        fun pos(p: MeasurePoint): Offset = Offset(
            (ox + (p.longitude - minLon) * lonScale * scale).toFloat(),
            (h - oy - (p.latitude - minLat) * scale).toFloat()
        )

        points.forEach { p ->
            drawCircle(color = signalColor(p.rssi), radius = 6.dp.toPx(), center = pos(p))
        }
        if (best != null) {
            drawCircle(
                color = Color.White,
                radius = 11.dp.toPx(),
                center = pos(best),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

private fun openInMaps(context: Context, p: MeasurePoint) {
    val uri = Uri.parse("geo:${p.latitude},${p.longitude}?q=${p.latitude},${p.longitude}(Mejor+senal+WiFi)")
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}
