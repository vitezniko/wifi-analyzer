package com.ruben.wifianalyzer

import android.net.wifi.ScanResult

enum class Band(val label: String) {
    B24("2.4 GHz"),
    B5("5 GHz"),
    B6("6 GHz")
}

data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val frequency: Int,
    val centerFreq: Int,
    val channel: Int,
    val band: Band,
    val widthMhz: Int,
    val vendor: String
) {
    val displayName: String get() = ssid.ifBlank { "(red oculta)" }
}

data class MeasurePoint(
    val latitude: Double,
    val longitude: Double,
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val timeMillis: Long,
    val manual: Boolean = false
)

object WifiMath {
    fun bandOf(freq: Int): Band = when {
        freq < 3000 -> Band.B24
        freq < 5925 -> Band.B5
        else -> Band.B6
    }

    fun channelOf(f: Int): Int = when {
        f == 2484 -> 14
        f in 2400..2483 -> (f - 2407) / 5
        f in 5000..5924 -> (f - 5000) / 5
        f == 5935 -> 2
        f in 5925..7125 -> (f - 5950) / 5
        else -> 0
    }

    fun channelToFreq(band: Band, ch: Int): Int = when (band) {
        Band.B24 -> if (ch == 14) 2484 else 2407 + 5 * ch
        Band.B5 -> 5000 + 5 * ch
        Band.B6 -> if (ch == 2) 5935 else 5950 + 5 * ch
    }

    fun widthMhz(code: Int): Int = when (code) {
        0 -> 20
        1 -> 40
        2 -> 80
        3, 4 -> 160
        5 -> 320
        else -> 20
    }
}

@Suppress("DEPRECATION")
fun ScanResult.toNetwork(): WifiNetwork {
    val f = frequency
    val width = WifiMath.widthMhz(channelWidth)
    val center = if (channelWidth > 0 && centerFreq0 > 0) centerFreq0 else f
    val mac: String = BSSID ?: ""
    val name: String = SSID ?: ""
    return WifiNetwork(
        ssid = name,
        bssid = mac.uppercase(),
        rssi = level,
        frequency = f,
        centerFreq = center,
        channel = WifiMath.channelOf(f),
        band = WifiMath.bandOf(f),
        widthMhz = width,
        vendor = OuiDatabase.lookup(mac, name)
    )
}
