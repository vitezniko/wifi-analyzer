package com.ruben.wifianalyzer

/**
 * Diccionario OUI basico: primeros 6 caracteres de la MAC (BSSID) -> fabricante.
 * Los prefijos se comprobaron contra el registro publico del IEEE.
 * Para anadir mas, copia una linea de add(...) y pon el fabricante y sus prefijos.
 */
object OuiDatabase {
    private val table = HashMap<String, String>()

    private fun add(vendor: String, vararg prefixes: String) {
        prefixes.forEach { table[it.replace(":", "").uppercase()] = vendor }
    }

    init {
        add(
            "TP-Link",
            "50:C7:BF", "14:CC:20", "98:DA:C4", "F4:F2:6D", "A4:2B:B0", "EC:08:6B", "18:D6:C7",
            "30:B5:C2", "00:1D:0F", "00:27:19",
            "00:31:92", "00:5F:67", "04:C8:45", "0C:EF:15", "10:27:F5", "14:EB:B6", "1C:61:B4",
            "20:23:51", "20:36:26", "24:2F:D0", "28:87:BA", "30:68:93", "30:DE:4B", "34:60:F9",
            "3C:52:A1", "3C:64:CF", "3C:6A:D2", "40:AE:30", "40:ED:00", "48:22:54", "50:91:E3",
            "54:AF:97", "5C:62:8B", "5C:A6:E6", "5C:E9:31", "60:83:E7", "60:A4:B7", "68:7F:F0",
            "6C:5A:B0", "74:FE:CE", "78:8C:B5", "7C:C2:C6", "58:04:4F", "A8:29:DC", "60:15:6F",
            "50:3D:D1", "98:03:8E", "28:91:04"
        )
        add(
            "Mercusys",
            "00:EB:D8", "08:8A:F1", "0C:1C:31", "30:16:9D", "94:74:2E", "FC:CA:10"
        )
        add(
            "Askey",
            "00:11:F5", "00:16:E3", "00:1B:9E", "00:21:63", "00:24:D2", "00:26:B6", "00:90:96",
            "08:33:ED", "08:6A:0A", "08:B0:55", "1C:24:CD", "1C:B0:44", "24:EC:99", "2C:EA:DC",
            "38:88:71", "4C:AB:F8", "4C:ED:DE", "50:5F:B5", "74:93:DA", "78:29:ED", "7C:B7:33",
            "94:0F:3B", "88:33:74"
        )
        add(
            "Sagemcom",
            "00:0E:59", "00:15:56", "00:19:4B", "00:1B:BF", "00:1E:74", "00:1F:95", "00:23:48",
            "00:25:69", "00:26:91", "00:37:B7", "00:60:4C", "00:78:9E", "00:CB:51", "00:F8:CC",
            "04:E3:1A", "08:3E:5D", "08:51:F2", "08:7B:12", "08:D5:9D", "0C:AC:8A", "10:06:45",
            "F8:08:4F", "A0:8E:78", "A0:55:1F", "2C:39:96", "44:05:3F", "20:B8:2B"
        )
    }

    // Pistas por nombre de red (muy habituales en Espana). Son orientativas.
    private val ssidHints = listOf(
        "MERCUSYS" to "Mercusys",
        "TP-LINK" to "TP-Link",
        "MOVISTAR_" to "Movistar (suele ser Askey o Mitrastar)",
        "WLAN_" to "Movistar (router antiguo)",
        "VODAFONE" to "Vodafone (suele ser Sagemcom o Huawei)",
        "ORANGE-" to "Orange (suele ser Sagemcom)",
        "MIWIFI" to "Orange (suele ser Sagemcom)",
        "LIVEBOX" to "Orange (Sagemcom)",
        "JAZZTEL" to "Jazztel",
        "DIGI" to "Digi",
        "YOIGO" to "Yoigo / MasMovil",
        "MASMOVIL" to "MasMovil",
        "HUAWEI" to "Huawei",
        "NETGEAR" to "Netgear",
        "XIAOMI" to "Xiaomi"
    )

    fun lookup(bssid: String, ssid: String): String {
        val hex = bssid.replace(":", "").replace("-", "").uppercase()
        if (hex.length < 6) return "Desconocido"

        table[hex.substring(0, 6)]?.let { return it }

        val firstByte = hex.substring(0, 2).toIntOrNull(16) ?: return "Desconocido"
        // Bit "administrada localmente": lo usan las redes secundarias / de invitados
        val isLocal = (firstByte and 0x02) != 0
        if (isLocal) {
            val base = String.format("%02X", firstByte and 0x02.inv()) + hex.substring(2, 6)
            table[base]?.let { return "$it (red secundaria)" }
        }

        val up = ssid.uppercase()
        ssidHints.firstOrNull { up.startsWith(it.first) }?.let { return "${it.second} (por el nombre de la red)" }

        return if (isLocal) "MAC virtual (red secundaria o repetidor)" else "Desconocido"
    }
}
