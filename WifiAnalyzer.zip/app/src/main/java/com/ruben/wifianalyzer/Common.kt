package com.ruben.wifianalyzer

import androidx.compose.material3.CardColors
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val SignalGreen = Color(0xFF4CAF50)
val SignalYellow = Color(0xFFFFC107)
val SignalRed = Color(0xFFF44336)

/** Verde: mejor que -50 dBm. Rojo: peor que -80 dBm. Amarillo: el resto. */
fun signalColor(rssi: Int): Color = when {
    rssi > -50 -> SignalGreen
    rssi >= -80 -> SignalYellow
    else -> SignalRed
}

fun signalLabel(rssi: Int): String = when {
    rssi > -50 -> "Excelente"
    rssi >= -80 -> "Media"
    else -> "Pobre"
}

fun signalFraction(rssi: Int): Float = ((rssi + 100) / 60f).coerceIn(0f, 1f)

private val palette = listOf(
    Color(0xFF4DD0E1), Color(0xFFFFB74D), Color(0xFFBA68C8), Color(0xFF81C784),
    Color(0xFFE57373), Color(0xFF64B5F6), Color(0xFFFFF176), Color(0xFFF06292),
    Color(0xFFA1887F), Color(0xFF90A4AE)
)

fun networkColor(key: String): Color = palette[(key.hashCode() and Int.MAX_VALUE) % palette.size]

fun formatTime(ms: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))

@Composable
fun cardColors(): CardColors =
    CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
