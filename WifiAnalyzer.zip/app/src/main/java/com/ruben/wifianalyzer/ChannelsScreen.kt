@file:OptIn(ExperimentalMaterial3Api::class)

package com.ruben.wifianalyzer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow

@Composable
fun ChannelsScreen(state: WifiUiState, modifier: Modifier = Modifier) {
    var bandIdx by rememberSaveable { mutableIntStateOf(0) }
    val band = Band.values()[bandIdx]
    val nets = state.networks.filter { it.band == band }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Band.values().forEachIndexed { i, b ->
                FilterChip(selected = i == bandIdx, onClick = { bandIdx = i }, label = { Text(b.label) })
            }
        }

        Text(
            "Eje X: canales. Eje Y: potencia en dBm. Donde se solapan varias curvas, ese canal esta saturado.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(colors = cardColors(), modifier = Modifier.fillMaxWidth()) {
            ChannelChart(
                nets = nets,
                band = band,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(8.dp)
            )
        }

        RecommendationCard(nets, band)

        if (nets.isEmpty()) {
            Text("No hay redes en esta banda ahora mismo.", style = MaterialTheme.typography.bodyMedium)
        }
        nets.sortedByDescending { it.rssi }.forEach { n ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(networkColor(n.bssid), CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(
                    n.displayName,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "Canal ${n.channel} - ${n.rssi} dBm",
                    color = signalColor(n.rssi),
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
private fun RecommendationCard(nets: List<WifiNetwork>, band: Band) {
    val rec = remember(nets, band) { recommendChannel(nets, band) }
    Card(colors = cardColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            if (nets.isEmpty()) {
                Text(
                    "Banda libre: ningun canal esta ocupado.",
                    style = MaterialTheme.typography.titleSmall
                )
            } else {
                Text(
                    "Canal mas libre en ${band.label}: $rec",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Es el que menos se solapa con las redes vecinas segun la potencia de cada una.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (band == Band.B24) {
                Text(
                    "En 2.4 GHz solo los canales 1, 6 y 11 no se pisan entre si.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun candidateChannels(band: Band): List<Int> = when (band) {
    Band.B24 -> listOf(1, 6, 11)
    Band.B5 -> listOf(36, 40, 44, 48, 149, 153, 157, 161, 165)
    Band.B6 -> (1..229 step 4).toList()
}

private fun channelLoad(nets: List<WifiNetwork>, band: Band, ch: Int): Double {
    val fc = WifiMath.channelToFreq(band, ch)
    return nets.sumOf { n ->
        if (abs(n.centerFreq - fc) < (n.widthMhz / 2 + 10)) 10.0.pow(n.rssi / 10.0) else 0.0
    }
}

private fun recommendChannel(nets: List<WifiNetwork>, band: Band): Int {
    val candidates = candidateChannels(band)
    return candidates.minByOrNull { channelLoad(nets, band, it) } ?: candidates.first()
}

private fun tickChannels(band: Band): List<Int> = when (band) {
    Band.B24 -> (1..13).toList()
    Band.B5 -> (36..64 step 4).toList() + (100..144 step 4).toList() + (149..177 step 4).toList()
    Band.B6 -> (1..233 step 4).toList()
}

private fun freqRange(nets: List<WifiNetwork>, band: Band): Pair<Float, Float> {
    if (band == Band.B24) return 2397f to 2487f
    val defLo = if (band == Band.B5) 5170f else 5945f
    if (nets.isEmpty()) return defLo to (defLo + 160f)
    var lo = nets.minOf { it.centerFreq - it.widthMhz / 2 } - 20f
    var hi = nets.maxOf { it.centerFreq + it.widthMhz / 2 } + 20f
    if (hi - lo < 120f) {
        val mid = (lo + hi) / 2f
        lo = mid - 60f
        hi = mid + 60f
    }
    return lo to hi
}

@Composable
fun ChannelChart(nets: List<WifiNetwork>, band: Band, modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer()
    val axisColor = MaterialTheme.colorScheme.onSurfaceVariant
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    val axisStyle = TextStyle(color = axisColor, fontSize = 10.sp)
    val range = freqRange(nets, band)
    val lo = range.first
    val hi = range.second

    Canvas(modifier) {
        val left = 40.dp.toPx()
        val right = size.width - 10.dp.toPx()
        val top = 14.dp.toPx()
        val bottom = size.height - 24.dp.toPx()
        val yMin = -100f
        val yMax = -30f

        fun xOf(f: Float): Float = left + (f - lo) / (hi - lo) * (right - left)
        fun yOf(d: Float): Float =
            bottom - (d.coerceIn(yMin, yMax) - yMin) / (yMax - yMin) * (bottom - top)

        // Rejilla y eje Y (dBm)
        for (d in listOf(-90, -80, -70, -60, -50, -40)) {
            val y = yOf(d.toFloat())
            drawLine(gridColor, Offset(left, y), Offset(right, y), strokeWidth = 1.dp.toPx())
            val t = measurer.measure("$d", axisStyle)
            drawText(t, topLeft = Offset(left - t.size.width - 6.dp.toPx(), y - t.size.height / 2f))
        }
        drawLine(axisColor, Offset(left, bottom), Offset(right, bottom), strokeWidth = 1.5.dp.toPx())

        // Eje X (canales)
        var lastLabelX = -1000f
        for (ch in tickChannels(band)) {
            val f = WifiMath.channelToFreq(band, ch).toFloat()
            if (f < lo || f > hi) continue
            val x = xOf(f)
            drawLine(axisColor, Offset(x, bottom), Offset(x, bottom + 4.dp.toPx()), strokeWidth = 1.dp.toPx())
            if (x - lastLabelX >= 22.dp.toPx()) {
                val t = measurer.measure("$ch", axisStyle)
                drawText(t, topLeft = Offset(x - t.size.width / 2f, bottom + 6.dp.toPx()))
                lastLabelX = x
            }
        }

        // Curvas de cada red (las debiles primero, para que las fuertes queden delante)
        nets.sortedBy { it.rssi }.forEach { n ->
            val c = networkColor(n.bssid)
            val half = n.widthMhz / 2f
            val x0 = xOf(n.centerFreq - half)
            val x1 = xOf(n.centerFreq + half)
            val xc = xOf(n.centerFreq.toFloat())
            val yTop = yOf(n.rssi.toFloat())
            val path = Path().apply {
                moveTo(x0, bottom)
                cubicTo(x0 + (xc - x0) * 0.5f, bottom, x0 + (xc - x0) * 0.5f, yTop, xc, yTop)
                cubicTo(xc + (x1 - xc) * 0.5f, yTop, xc + (x1 - xc) * 0.5f, bottom, x1, bottom)
                close()
            }
            drawPath(path, c.copy(alpha = 0.22f))
            drawPath(path, c, style = Stroke(width = 2.dp.toPx()))
        }

        // Nombres de las 10 redes mas fuertes
        nets.sortedByDescending { it.rssi }.take(10).forEach { n ->
            val xc = xOf(n.centerFreq.toFloat())
            val yTop = yOf(n.rssi.toFloat())
            val t = measurer.measure(
                n.displayName.take(16),
                TextStyle(color = networkColor(n.bssid), fontSize = 10.sp)
            )
            val x = (xc - t.size.width / 2f).coerceIn(left, max(left, right - t.size.width))
            val y = (yTop - t.size.height - 2.dp.toPx()).coerceAtLeast(0f)
            drawText(t, topLeft = Offset(x, y))
        }
    }
}
