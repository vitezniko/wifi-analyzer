package com.ruben.wifianalyzer

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class WifiUiState(
    val networks: List<WifiNetwork> = emptyList(),
    val visibleBands: Set<Band> = Band.values().toSet(),
    val locationEnabled: Boolean = true,
    val lastScanMillis: Long = 0L,
    val scanNotice: String? = null,
    val trackedSsid: String? = null,
    val mappingEnabled: Boolean = true,
    val points: List<MeasurePoint> = emptyList(),
    val locating: Boolean = false,
    val locationNotice: String? = null
) {
    val visibleNetworks: List<WifiNetwork> get() = networks.filter { it.band in visibleBands }
    val bestPoint: MeasurePoint? get() = points.maxByOrNull { it.rssi }
}

class WifiViewModel(app: Application) : AndroidViewModel(app) {

    private val scanner = WifiScanner(app)
    private val _state = MutableStateFlow(WifiUiState())
    val state: StateFlow<WifiUiState> = _state.asStateFlow()

    private var scanJob: Job? = null
    private var collectJob: Job? = null
    private var captureJob: Job? = null
    private var lastPoint: MeasurePoint? = null

    fun startScanning() {
        refreshLocationEnabled()
        if (scanJob?.isActive == true) return

        collectJob = viewModelScope.launch {
            scanner.resultsFlow()
                .map { raw -> raw.map { it.toNetwork() }.sortedByDescending { it.rssi } }
                .flowOn(Dispatchers.Default)
                .collect { onNetworks(it) }
        }
        scanJob = viewModelScope.launch {
            while (isActive) {
                triggerScan()
                delay(SCAN_INTERVAL_MS)
            }
        }
    }

    fun stopScanning() {
        scanJob?.cancel()
        collectJob?.cancel()
        captureJob?.cancel()
        scanJob = null
        collectJob = null
        captureJob = null
        _state.update { it.copy(locating = false) }
    }

    fun scanNow() {
        viewModelScope.launch { triggerScan() }
    }

    private suspend fun triggerScan() {
        val started = scanner.requestScan()
        if (started) {
            _state.update { it.copy(scanNotice = null) }
        } else {
            val cached = withContext(Dispatchers.Default) {
                scanner.readResults().map { it.toNetwork() }.sortedByDescending { it.rssi }
            }
            _state.update {
                it.copy(
                    scanNotice = "Android limita los escaneos (unos 4 cada 2 minutos). " +
                        "Se muestran los ultimos resultados disponibles."
                )
            }
            if (cached.isNotEmpty()) onNetworks(cached)
        }
    }

    private fun onNetworks(nets: List<WifiNetwork>) {
        _state.update { it.copy(networks = nets, lastScanMillis = System.currentTimeMillis()) }
        if (_state.value.mappingEnabled) capture(manual = false)
    }

    private fun capture(manual: Boolean) {
        if (captureJob?.isActive == true) return
        val st = _state.value
        val tracked = st.trackedSsid
        val pool = if (tracked != null) st.networks.filter { it.ssid == tracked } else st.networks
        val candidate = pool.maxByOrNull { it.rssi } ?: return

        captureJob = viewModelScope.launch {
            _state.update { it.copy(locating = true, locationNotice = null) }
            val loc = scanner.currentLocation()
            if (loc == null) {
                _state.update {
                    it.copy(
                        locating = false,
                        locationNotice = "No se pudo obtener la ubicacion. Comprueba que el GPS esta activado " +
                            "y, si estas dentro de casa, acercate a una ventana."
                    )
                }
                return@launch
            }
            val prev = lastPoint
            if (!manual && prev != null) {
                val d = FloatArray(1)
                Location.distanceBetween(prev.latitude, prev.longitude, loc.latitude, loc.longitude, d)
                if (d[0] < MIN_DISTANCE_M) {
                    _state.update { it.copy(locating = false) }
                    return@launch
                }
            }
            val point = MeasurePoint(
                latitude = loc.latitude,
                longitude = loc.longitude,
                ssid = candidate.displayName,
                bssid = candidate.bssid,
                rssi = candidate.rssi,
                timeMillis = System.currentTimeMillis(),
                manual = manual
            )
            lastPoint = point
            _state.update { it.copy(locating = false, points = (it.points + point).takeLast(MAX_POINTS)) }
        }
    }

    fun markPointNow() = capture(manual = true)

    fun clearPoints() {
        lastPoint = null
        _state.update { it.copy(points = emptyList(), locationNotice = null) }
    }

    fun setMapping(enabled: Boolean) {
        _state.update { it.copy(mappingEnabled = enabled) }
    }

    fun toggleBand(band: Band) {
        _state.update {
            val next = if (band in it.visibleBands) it.visibleBands - band else it.visibleBands + band
            it.copy(visibleBands = next)
        }
    }

    fun toggleTracked(ssid: String) {
        if (ssid.isBlank()) return
        _state.update { it.copy(trackedSsid = if (it.trackedSsid == ssid) null else ssid) }
    }

    fun refreshLocationEnabled() {
        _state.update { it.copy(locationEnabled = scanner.isLocationEnabled()) }
    }

    override fun onCleared() {
        stopScanning()
        super.onCleared()
    }

    private companion object {
        const val SCAN_INTERVAL_MS = 30_000L
        const val MIN_DISTANCE_M = 3f
        const val MAX_POINTS = 500
    }
}
