@file:OptIn(ExperimentalMaterial3Api::class)

package com.ruben.wifianalyzer

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun NetworksScreen(
    state: WifiUiState,
    onToggleBand: (Band) -> Unit,
    onTrack: (String) -> Unit,
    onOpenLocationSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val visible = state.visibleNetworks

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Band.values().forEach { band ->
                    val count = state.networks.count { it.band == band }
                    FilterChip(
                        selected = band in state.visibleBands,
                        onClick = { onToggleBand(band) },
                        label = { Text("${band.label} ($count)") }
                    )
                }
            }
        }

        if (!state.locationEnabled) {
            item {
                WarningCard(
                    text = "La ubicacion del movil esta desactivada. Android no entrega la lista de " +
                        "redes Wi-Fi si el GPS/ubicacion esta apagado.",
                    action = "Activar ubicacion",
                    onAction = onOpenLocationSettings
                )
            }
        }

        state.scanNotice?.let { notice ->
            item {
                Text(
                    notice,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            val time = if (state.lastScanMillis > 0) " - actualizado ${formatTime(state.lastScanMillis)}" else ""
            Text(
                "${visible.size} redes visibles$time",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (visible.isEmpty()) {
            item {
                Text(
                    if (state.networks.isEmpty()) "Buscando redes..." else "No hay redes en las bandas seleccionadas.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        items(visible) { n ->
            NetworkCard(
                n = n,
                tracked = state.trackedSsid != null && state.trackedSsid == n.ssid,
                onClick = { onTrack(n.ssid) }
            )
        }

        item {
            Text(
                "Toca una red para seguirla en el mapa de cobertura (en vez de la mas potente).",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun NetworkCard(n: WifiNetwork, tracked: Boolean, onClick: () -> Unit) {
    val color = signalColor(n.rssi)
    Card(onClick = onClick, colors = cardColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).background(color, CircleShape))
                Spacer(Modifier.width(10.dp))
                Text(
                    n.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text("${n.rssi} dBm", color = color, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { signalFraction(n.rssi) },
                color = color,
                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "${signalLabel(n.rssi)} - ${n.band.label} - Canal ${n.channel} - ${n.widthMhz} MHz",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                n.bssid,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "Fabricante: ${n.vendor}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (tracked) {
                Text(
                    "Siguiendo esta red en el mapa",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun WarningCard(text: String, action: String, onAction: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2A12)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = Color(0xFFFFE0B2), style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onAction) { Text(action) }
        }
    }
}
